/** @file vl_nnpool.cpp
 ** @brief A non-CUDA wrapper
 **/

#include "vl_nnpool.cu"