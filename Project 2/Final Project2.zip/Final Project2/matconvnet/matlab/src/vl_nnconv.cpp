/** @file vl_nnconv.cpp
 ** @brief A non-CUDA wrapper
 **/

#include "vl_nnconv.cu"
